INSERT INTO `position` (`pId`, `name`, `url`, `Permission`) VALUES (1, '系统管理', 'system', 'userIndex:system');
INSERT INTO `position` (`pId`, `name`, `url`, `Permission`) VALUES (2, '权限管理', 'position', 'userIndex:position');
INSERT INTO `position` (`pId`, `name`, `url`, `Permission`) VALUES (3, '人员管理', 'userList', 'userIndex:userList');
INSERT INTO `position` (`pId`, `name`, `url`, `Permission`) VALUES (4, '销售管理', 'sell', 'userIndex:sell');
