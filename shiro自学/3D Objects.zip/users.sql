INSERT INTO `users` (`id`, `username`, `password`, `password_salt`, `status`) VALUES (1, 'zhangsan', 'e41cd85110c7533e3f93b729b25235c3', 'sxt', '开启');
INSERT INTO `users` (`id`, `username`, `password`, `password_salt`, `status`) VALUES (2, 'wangwu', 'e41cd85110c7533e3f93b729b25235c3', 'sxt', '开启');
