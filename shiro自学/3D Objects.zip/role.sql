INSERT INTO `role` (`roleId`, `name`) VALUES (1, '管理员');
INSERT INTO `role` (`roleId`, `name`) VALUES (2, '销售员');
