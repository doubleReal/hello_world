INSERT INTO `userrole` (`urid`, `uid`, `rid`) VALUES (1, 1, 1);
INSERT INTO `userrole` (`urid`, `uid`, `rid`) VALUES (2, 2, 2);
