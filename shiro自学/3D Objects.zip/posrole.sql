INSERT INTO `posrole` (`rpid`, `rid`, `pid`) VALUES (1, 1, 1);
INSERT INTO `posrole` (`rpid`, `rid`, `pid`) VALUES (2, 1, 2);
INSERT INTO `posrole` (`rpid`, `rid`, `pid`) VALUES (3, 1, 3);
INSERT INTO `posrole` (`rpid`, `rid`, `pid`) VALUES (4, 1, 4);
INSERT INTO `posrole` (`rpid`, `rid`, `pid`) VALUES (5, 2, 4);
